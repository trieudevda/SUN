import 'dart:ffi';

class Setting{
  String? idCustomer;
  Bool? music;
  Bool? sound;
  Setting({this.idCustomer, this.music, this.sound});
  // Future<List<String,dynamic>> read()async{
  //
  // }
}