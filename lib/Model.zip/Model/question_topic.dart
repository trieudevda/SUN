class QuestionDetail{
  String? nameQuestionTopic;
  String? status;
  QuestionDetail({this.nameQuestionTopic,this.status});
}