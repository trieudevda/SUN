class Statistical{
  String? idCustomer;
  int? questionAnswered;
  int? rightAnswer;
  int? wrongAnswer;
  double? exactPercentage;
  double? winTheGame;
  int? point;
  Statistical({this.idCustomer, this.questionAnswered, this.rightAnswer,this.wrongAnswer, this.exactPercentage, this.winTheGame,this.point});
}