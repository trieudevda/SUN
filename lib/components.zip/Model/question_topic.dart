import 'main_connect_firebase.dart';

class QuestionTopic{
  String? nameQuestionTopic;
  String? status;
  List? questions;
  QuestionTopic({this.nameQuestionTopic,this.status,this.questions});
}