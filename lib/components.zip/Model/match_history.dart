class MatchHistory{
  final id;
  final id_customer;
  final point;
  final status;
  MatchHistory({this.id, this.id_customer, this.point,this.status});
}