class Friend{
  String? idCustomer;
  String? idFriendCustomer;
  String? status;
  Friend({this.idCustomer,this.idFriendCustomer,this.status});
}